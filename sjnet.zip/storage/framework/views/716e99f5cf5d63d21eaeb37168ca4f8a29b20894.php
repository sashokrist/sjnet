<?php $__env->startSection('title'); ?>
    SJ NET
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <body>
        <div class="flex-center text-center position-ref full-height stress" >

            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(auth()->guard()->check()): ?>
                        <a class="btn btn-primary btn-lg" href="<?php echo e(url('/profile')); ?>">Dashboard</a>
                    <?php else: ?>
                        <a class="btn btn-primary" href="<?php echo e(route('login')); ?>">Login</a>

                        <?php if(Route::has('register')): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('register')); ?>">Register</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </div>

    </body>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>