<?php $__env->startSection('content'); ?>
<div class="text-center">
    <div class="col-12">
        <div class="card">
            <div class="card-header">Dashboard</div>

            <div class="card-body">
                <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                        <h3><?php echo e($user->name); ?></h3>
                        <h3><?php echo e($user->email); ?></h3>
                    </div>
                <?php endif; ?>

                You are logged in!
            </div>
        </div>
    </div>
    <section class="row new-post justify-content-center">
        <div class="col-8">
            <header><h3>What do you have to say?</h3></header>
            <form action="<?php echo e(route('post.create')); ?> " method="post">
                <div class="form-group">
                    <textarea class="form-control" name="body" id="new-post" rows="5" placeholder="enter your post here"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Create Post</button>
                <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
            </form>
        </div>

    </section>
    <section class="row new-post justify-content-center">
        <div class="col-8">
            <header><h3>What other people say?</h3></header>
            <article class="post">
                <p>This post is submit by laravel default engine and will repeat many many times
                    This post is submit by laravel default engine and will repeat many many times</p>
                <div class="info">
                    posted by Sasho on 12 Nov 2018
                </div>
                <div class="interaction">
                    <a href="#">Like</a>
                    <a href="#">DisLike</a>
                    <a href="#">Edit</a>
                    <a href="#">Delete</a>
                </div>
            </article>
            <article class="post">
                <p>This post is submit by laravel default engine and will repeat many many times
                    This post is submit by laravel default engine and will repeat many many times</p>
                <div class="info">
                    posted by Sasho on 12 Nov 2018
                </div>
                <div class="interaction">
                    <a href="#">Like</a>
                    <a href="#">DisLike</a>
                    <a href="#">Edit</a>
                    <a href="#">Delete</a>
                </div>
            </article>
        </div>

    </section>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>